/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect, useRef } from 'react';
import { motion, AnimatePresence, useScroll, useTransform } from 'motion/react';
import { 
  Home, 
  BookOpen, 
  Zap, 
  Info, 
  ChevronRight, 
  ChevronLeft,
  Monitor, 
  Cpu, 
  Dna, 
  FlaskConical,
  X,
  Menu,
  ArrowLeft,
  Gamepad2
} from 'lucide-react';
import { Canvas, useFrame } from '@react-three/fiber';
import { Float, PerspectiveCamera } from '@react-three/drei';
import * as THREE from 'three';

// --- Types ---
type Page = 'intro' | 'home' | 'comics' | 'fun-facts' | 'about' | 'game';

interface Comic {
  id: number;
  title: string;
  author: string;
  description: string;
  image: string; // Cover image
  pages: string[]; // Comic pages
}


const COMICS: Comic[] = [
  { 
    id: 1, 
    title: 'Combined Gas Law', 
    author: 'Renee Abalos', 
    description: 'Renee Abalos is a G 10 student from St. Pio of tarlac Montessori School. She creates education comics, blending science and storytelling, her latest work explores the Combined Gas Law in a fun and engaging way.', 
    image: 'https://i.postimg.cc/9Mfky3qg/renee-1.jpg',
    pages: [
      'https://i.postimg.cc/jqnb1NDY/renee-2.png',
      'https://i.postimg.cc/B68dd9Qb/renee-3.png',
      'https://i.postimg.cc/5NWZkrcN/renee.png',
    ]
  },
  { 
    id: 2, 
    title: 'Boyles Law', 
    author: 'Rhiana Briones', 
    description: 'Rhiana Briones is a Grade 10 student from St. Pio of Tarlac Montessori School. She creates educational comics that combine creativity and learning, bringing scientific concepts to life through engaging storytelling. Her latest work explores the Boyles Law in a fun, clear, and imaginative way, making complex ideas easier to understand and enjoyable to read.', 
    image: 'https://i.postimg.cc/sg71Cqx0/13d6189b-59c5-4b2c-88c8-aa6ca1084462.jpg',
    pages: [
      'https://i.postimg.cc/cH9LcNkB/3c698083-03d0-43fa-a169-c2d5ea57a2ac.jpg',
      'https://i.postimg.cc/qBF7h43p/e359dc2b-054e-4e7f-8aa3-52ae4181e821.jpg',
      'https://i.postimg.cc/P5sryyyZ/13a1b75f-9c5c-46aa-add2-778405df1892.jpg',
      'https://i.postimg.cc/F1tmPFjM/181a7ead-1538-412a-a852-78ba71349a7e.jpg',
    ]
  },
  { 
    id: 3, 
    title: 'Charles Law', 
    author: 'Rachel Chan', 
    description: 'Rachel Chan, a Grade 10 student from St. Pio of Tarlac Montessori School, turns science lessons into captivating comic stories. In her latest piece, she brings Charles’ Law to life, making it both fun and easy to understand..', 
    image: 'https://i.postimg.cc/zXJ1GQxx/630858e5-c2d0-4b84-98d3-f8949d7246c9.jpg',
    pages: [
      'https://i.postimg.cc/KY36WhY7/23698fb8-80de-43f1-96fb-1081e915e6c2.jpg',
      'https://i.postimg.cc/vTbCD1tT/64de1c41-bfe5-46f2-ae8e-72588ea7e138.jpg',
      'https://i.postimg.cc/4N8jNx75/a29f43b6-d148-4d1e-a0ff-bbd8ef471491.jpg',
      'https://i.postimg.cc/wvcGKqYm/7e2b2f12-d5d2-42a0-802f-f43a22a8e624.jpg',
    ]
  },
  { 
    id: 4, 
    title: 'Gas Law', 
    author: 'Gian Ico', 
    description: 'Gian Ico, a Grade 10 student at St. Pio of Tarlac Montessori School, creates educational comics that simplify scientific ideas. His latest work explores the Gas Laws through clear and engaging visuals.', 
    image: 'https://i.postimg.cc/y6LL0r1B/503b0b66-058a-4740-8d14-3c6aeecdb715.jpg',
    pages: [
      'https://i.postimg.cc/YCW8KrQP/bb11037d-34a3-410e-8ae8-42215d1385c1.jpg',
      'https://i.postimg.cc/Xv6LnR8F/d5052096-9f04-4c04-a955-8c759c74c07d.jpg',
      'https://i.postimg.cc/NGCxK9DF/47f3f876-1255-448d-a28b-9ce0baab207d.jpg',
    ]
  },
  { 
    id: 5, 
    title: 'Avogadros Law', 
    author: 'Enzo Moyano', 
    description: 'Enzo Moyano, a Grade 10 student from St. Pio of Tarlac Montessori School, produces educational comics that combine scientific principles with visual storytelling. His recent work presents Avogadros Law in an engaging and accessible format.', 
    image: 'https://i.postimg.cc/pyNhDHyB/0aa0d01e-0760-4ba1-a9f1-0e4b3c77fd87.jpg',
    pages: [
      'https://i.postimg.cc/wx1wcQ7v/15516315-75bd-43f6-9d33-39be33f362cc.jpg',
      'https://i.postimg.cc/HWFBS8y2/17c7d3a1-5de9-40bf-a978-923dab256252.jpg',
      'https://i.postimg.cc/m2MVKZYV/add419a0-5f91-42d3-896c-a477bcf7d139.jpg',
    ]
  },
  { 
    id: 6, 
    title: 'Gay Lussac Law', 
    author: 'Joseph Tesorero', 
    description: 'Joseph Tesorero, a Grade 10 student at St. Pio of Tarlac Montessori School, creates educational comics that make science easier to understand. His latest work explores Gay-Lussacs Law through clear and engaging visuals.', 
    image: 'https://i.postimg.cc/BvDmfSfN/92b3ce8f-8229-40ac-80eb-79c27db19fe4.jpg',
    pages: [
      'hhttps://i.postimg.cc/ydHvVM7v/45a48d6d-29a8-4bea-abcc-89f557192242.jpg',
      'https://i.postimg.cc/Kz2JZ6Zm/1f8b9d01-7c46-4fcc-820d-8c708d20ce5a.jpg',
      'https://i.postimg.cc/zDp0r26h/29f94597-d526-4a84-9d2c-cc8eb2f9aec2.jpg',
      'https://i.postimg.cc/28KGqbzw/702d7435-af1f-499e-a3f2-f0f388399dde.jpg',
      'https://i.postimg.cc/VNyFRxr2/01f5ae5f-01bb-48a0-8694-c71929ea065a.jpg',
      'https://i.postimg.cc/7LvNVFJb/c1e87099-fa60-4de6-acf9-d786cf0086ae.jpg',
    ]
  },
  { 
    id: 7, 
    title: 'Combined Gas Law 2', 
    author: 'Janine Ticman', 
    description: 'A Grade 10 student from St. Pio of Tarlac Montessori School, Janine Ticman brings science to life through creative comics. Her latest piece presents the Combined Gas Law in a fun and imaginative way, making complex ideas easier to understand.', 
    image: 'https://i.postimg.cc/KcdrxXQW/b667befe-84b2-4511-9980-e22ebd0eddea.jpg',
    pages: [
      'https://i.postimg.cc/x1QvNKwf/db9a1c8d-79c9-4f04-805a-004b89846049.jpg',
      'https://i.postimg.cc/tgjhH2vf/57763648-63ec-4cab-99cc-77ce0449fe7f.jpg',
      'https://i.postimg.cc/wv33KNzn/8872d93e-241d-43f4-81b2-aa9a9dcf77a3.jpg',
    ]
  },
];

const FUN_FACTS = [
  // Biomolecules (35)
  { id: 1, category: 'biomolecules', fact: "Biomolecules include large molecules like proteins, carbohydrates, lipids (fats), and nucleic acids (like DNA). They also include smaller ones like vitamins and hormones. " },
  { id: 2, category: 'biomolecules', fact: "Almost all biomolecules are organic compounds, which means they are built around the element carbon. Interestingly, the vast complexity of human life is driven by just four primary elements: oxygen, carbon, hydrogen, and nitrogen. Together, these four make up about 96% of your body mass." },
  { id: 3, category: 'biomolecules', fact: "Biomolecules are the most essential organic molecules, which are involved in the maintenance and metabolic processes of living organisms. Even though there are millions of different species on Earth, many of them use the same types of biomolecules to live." },
  { id: 4, category: 'biomolecules', fact: "Our bodies are experts at saving for a rainy day when it comes to energy. We store excess fuel as glycogen (in the liver and muscles) or as body fat. However, we cant store amino acids, which are the building blocks of protein. Because we cannot store them, we need to replenish our protein supply daily. If the bodys protein needs aren't met through your diet, it will eventually begin breaking down its own muscle mass and even affect bone health to get the nutrients it needs. This is why consistent protein intake is so vital for maintaining your physical strength.." },
  { id: 5, category: 'biomolecules', fact: "Without lipids, digestion and absorption of food would not be possible. Beyond just storing energy, the body requires fats to cushion and protect internal organs from impact, regulate body temperature by providing insulation, and absorb essential vitamins, specifically A, D, E, and K, which are fat-soluble and cannot be processed by the body without lipids present." },
  { id: 6, category: 'biomolecules', fact: "Biomolecules determine your traits Your DNA or nucleic acid carries the instructions that control your eye color, height, and more." },
  { id: 7, category: 'biomolecules', fact: "All biomolecules are connected Carbohydrates, proteins, lipids, and nucleic acids work together. For example, DNA (nucleic acid) codes for proteins, and enzymes (proteins) help build other biomolecules." },
  { id: 8, category: 'biomolecules', fact: "Heat can destroy biomolecules Cooking food changes proteins and enzymes (like when an egg turns solid)." },
  { id: 9, category: 'biomolecules', fact: " Some proteins glow! → Biomolecule GFP is a protein, which is a type of biomolecule." },
  { id: 10, category: 'biomolecules', fact: "Even bacteria have biomolecules → Biomolecule This is about the presence of biomolecules in living things." },
  { id: 11, category: 'biomolecules', fact: "Some RNA molecules, called ribozymes, can catalyze chemical reactions, just like proteins.This supports the idea of an early “RNA world” in evolution" },
  { id: 12, category: 'biomolecules', fact: "Proteins are not rigid—they fold into specific 3D shapes.A small change in shape can completely alter their function (e.g., enzymes losing activity if denatured)." },
  { id: 13, category: 'biomolecules', fact: "The genetic code is nearly universal across all organisms, from bacteria to humans.This suggests a common evolutionary origin" },
  { id: 14, category: 'biomolecules', fact: "Certain biomolecules emit tiny amounts of light through chemical reactions (bioluminescence-like processes).Its too faint for human eyes, but sensitive cameras can detect it." },
  { id: 15, category: 'biomolecules', fact: "Carbohydrates can branch in many ways, making them structurally more diverse than DNA or proteins.This complexity is why theyre harder to study.." },
  { id: 16, category: 'biomolecules', fact: "Biomolecules are the fundamental molecules that make up all living things. Without them, cells couldnt exist, and life as we know it wouldnt be possible. Think of them as the Lego pieces of life.." },
  { id: 17, category: 'biomolecules', fact: "While we often think of biomolecules like DNA and proteins as just “instructions” or “structural components,” they also act as enzymes (speeding up reactions), hormones (messengers), and even energy storage (like fats and glycogen)." },
  { id: 18, category: 'biomolecules', fact: "Proteins are made of chains of amino acids, but their 3D folded shapes determine their function. A tiny misfolding can cause serious diseases, like Alzheimers or cystic fibrosis. Natures protein origami is mind-blowing!" },
  { id: 19, category: 'biomolecules', fact: "Carbohydrates arent just simple sugars like glucose. Some, like cellulose in plants, form huge, strong structures that give plants their rigidity. Humans cant even digest cellulose, yet its essential for fiber in our diet." },
  { id: 20, category: 'biomolecules', fact: "The DNA in a single human cell, if stretched out, would be about 2 meters long! And yet it fits inside a nucleus just a few micrometers wide. DNA stores massive amounts of information in a tiny space, making it the ultimate biological hard drive." },
  { id: 21, category: 'biomolecules', fact: "Protein Folding and Chaperones: Proteins don't just fold randomly; they often require chaperone proteins to ensure they reach the correct 3D shape. If they misfold, they can clump together, which is a primary factor in diseases like Alzheimers." },
  { id: 22, category: 'biomolecules', fact: "The RNA World Hypothesis: Many scientists believe that before DNA or proteins existed, RNA did both jobs. RNA can store genetic information (like DNA) and act as a catalyst (like a protein enzyme)." },
  { id: 23, category: 'biomolecules', fact: "Post-Translational Modification: A protein isn't always finished once it's built. Cells often add decorations like phosphate groups or sugars, to a protein to turn it on or off, much like a biological light switch." },
  { id: 24, category: 'biomolecules', fact: "Nucleotide Coenzymes: Some biomolecules are multitaskers. For example, nicotinamide adenine dinucleotide is a nucleotide, but its main job isn't storing data—its carrying high-energy electrons during cellular respiration." },
  { id: 25, category: 'biomolecules', fact: "Intrinsic Disorder: Not all proteins have a rigid shape. Intrinsically Disordered Proteins (IDPs) are flexible and only take a specific shape when they bind to a partner molecule, allowing one protein to interact with many different targets." },
  { id: 26, category: 'biomolecules', fact: "DNA can stretch a lot If you stretch the DNA from a single human cell, it can be about 2 meters long, even though it fits inside a tiny nucleus." },
  { id: 27, category: 'biomolecules', fact: "Lipids can form bubbles on their own When placed in water, some lipids automatically form cell-like structures (liposomes)—this is similar to how cell membranes are formed." },
  { id: 28, category: 'biomolecules', fact: "Enzymes can be reused many times A single enzyme molecule can catalyze thousands of reactions per second without being used up." },
  { id: 29, category: 'biomolecules', fact: "Hemoglobin changes color depending on oxygen Blood looks bright red when oxygen-rich and darker when oxygen-poor because hemoglobin changes its structure slightly." },
  { id: 30, category: 'biomolecules', fact: "Some proteins act as motors Proteins like myosin and kinesin can “walk” inside cells, helping transport materials and enabling movement" },
  { id: 31, category: 'biomolecules', fact: "Hyaluronic acid is a carbohydrate found in your joints that acts as a lubricant." },
  { id: 32, category: 'biomolecules', fact: "Pepsin is an enzyme in your stomach that breaks down proteins from the food you eat." },
  { id: 33, category: 'biomolecules', fact: "Ovalbumin is the main protein found in egg whites." },
  { id: 34, category: 'biomolecules', fact: "Triglycerides are the main form of stored energy in the body's fat cells." },
  { id: 35, category: 'biomolecules', fact: "Histones are proteins that act as spools for DNA to wind around, keeping it organized." },
  
  // Chemical Reactions (35)
  { id: 36, category: 'reactions', fact: "Your own body is like a chemical factory, with thousands of reactions happening every second to keep you alive." },
  { id: 37, category: 'reactions', fact: "Every time lightning strikes, it triggers a chemical reaction in the air that converts oxygen into ozone. Lightning splits oxygen molecules, which can collide with other oxygen molecules to form ozone, helping to replenish and strengthen the ozone layer." },
  { id: 38, category: 'reactions', fact: "Some animals, like fireflies, use a special chemical reaction called bioluminescence to produce light and glow in the dark." },
  { id: 39, category: 'reactions', fact: "Digestion is a series of chemical reactions because it breaks down large, complex food molecules into smaller, simpler molecules that the body can absorb. Special proteins called enzymes in your stomach and intestines cause these chemical changes, transforming food into the energy and building blocks your body needs." },
  { id: 40, category: 'reactions', fact: "Photosynthesis is a fundamental chemical reaction—in fact, it is often considered the most important chemical reaction on Earth. It is a complex process where green plants, algae, and some bacteria use chlorophyll to absorb light energy and convert carbon dioxide into glucose and oxygen." },
  { id: 41, category: 'reactions', fact: "Here are reactions that oscillate between colors repeatedly without stopping for a while. A famous example is the Belousov Zhabotinsky reaction, which cycles through reds, blues, and clear states—almost like a chemical heartbeat." },
  { id: 42, category: 'reactions', fact: "In catalysis, certain reactions need a surface (like metals) to occur faster. Thats how catalytic converters in cars clean exhaust gases." },
  { id: 43, category: 'reactions', fact: "Chemical reactions can form stripes, spots, and spirals known as reaction-diffusion systems. These help explain patterns on animal skins—like zebra stripes and leopard spots." },
  { id: 44, category: 'reactions', fact: "In chemistry, molecules can form in “left-handed” or “right-handed” versions. This concept is called Chirality, and its crucial—your body often only recognizes one version of a molecule." },
  { id: 45, category: 'reactions', fact: "Some reactions are so slow that they take years (or longer) Not all reactions are fast—some happen extremely slowly. Rusting iron is a good example of a gradual reaction called oxidation, which can take months or years to fully show." },
  { id: 46, category: 'reactions', fact: "Reaction Intermediates: Most reactions don't happen in one big jump. They occur in a series of elementary steps.The short-lived molecules created and destroyed during these steps are called intermediates—they exist for only a fraction of a second." },
  { id: 47, category: 'reactions', fact: "Photochemical Reactions: Some reactions are powered entirely by light rather than heat. In these cases, photons provide the energy to break chemical bonds. This is how your eyes detect light and how the ozone layer is formed." },
  { id: 48, category: 'reactions', fact: "The Role of Entropy: A reaction doesn't just happen because it releases energy (enthalpy); it also depends on entropy (disorder). If a reaction creates a gas from a solid, the increase in disorder makes the reaction more likely to occur." },
  { id: 49, category: 'reactions', fact: "Surface Area and Rate: For reactions involving solids (like a tablet dissolving), the speed is limited by the surface area. This is why powdered medicine works faster than a solid pill—there are more collision sites available for the reaction." },
  { id: 50, category: 'reactions', fact: "Transition States: At the very peak of the activation energy curve, molecules form a transition state. This is a highly unstable, high-energy arrangement where old bonds are halfway broken, and new bonds are halfway formed." },
  { id: 51, category: 'reactions', fact: "Some chemical reactions, like the decomposition of azides, release energy rapidly but dont produce noticeable heat, making them “cold” detonations." },
  { id: 52, category: 'reactions', fact: "The Belousov Zhabotinsky reaction produces oscillating color patterns, showing that chemical reactions can spontaneously create order." },
  { id: 53, category: 'reactions', fact: "Certain gas-evolving reactions, like hydrogen reacting with metals, can generate popping or hissing sounds as bubbles form." },
  { id: 54, category: 'reactions', fact: "The decomposition of hydrogen peroxide with manganese dioxide releases oxygen gas rapidly, creating a foamy eruption in seconds." },
  { id: 55, category: 'reactions', fact: "Some reactions in metastable solutions “remember” their previous states, showing delayed responses when triggered again." },
  { id: 56, category: 'reactions', fact: "Some compounds, like silver halides, only react when exposed to light, which is the basis of photography." },
  { id: 57, category: 'reactions', fact: "Some reactions, like electron transfers, occur in quadrillionths of a second, too fast for the human eye to detect." },
  { id: 58, category: 'reactions', fact: "Some insects, like bombardier beetles, use chemical reactions to spray boiling-hot liquid at predators." },
  { id: 59, category: 'reactions', fact: "Certain redox reactions involving transition metals can temporarily make solutions weakly magnetic." },
  { id: 60, category: 'reactions', fact: " Enzyme networks in cells can behave like logic circuits, processing information chemically." },
  { id: 61, category: 'reactions', fact: "Certain alkali metals, like potassium or sodium, react violently with water, producing heat, gas, and even flames underwater." },
  { id: 62, category: 'reactions', fact: "Some reactions absorb heat and feel cold These are called endothermic reactions—like instant cold packs used for injuries." },
  { id: 63, category: 'reactions', fact: "Reactions can happen without touching (electron transfer)In some reactions, electrons move between substances without direct contact, like in batteries." },
  { id: 64, category: 'reactions', fact: "Fireflies use chemical reactions to glow Their light comes from a reaction involving luciferin, oxygen, and an enzyme—producing light with almost no heat." },
  { id: 65, category: 'reactions', fact: "Explosions are just very fast reactions Explosions happen when reactions release energy extremely quickly, producing gases and heat at once." },
  { id: 66, category: 'reactions', fact: "Equilibrium means reactions dont stopEven when a reaction “looks finished,” particles are still reacting forward and backward at the same rate." },
  { id: 67, category: 'reactions', fact: "The 'blue bottle' experiment shows a reversible redox reaction that changes color when shaken." },
  { id: 68, category: 'reactions', fact: "Corrosion isn't just for iron; even gold can corrode if exposed to specific chemicals like aqua regia." },
  { id: 69, category: 'reactions', fact: "Polymerization is the chemical reaction used to create plastics from small molecules." },
  { id: 70, category: 'reactions', fact: "Lightning creates ozone (O3) in the atmosphere through a high-energy chemical reaction." }
];

const BIOMOLECULE_ITEMS = [
  { id: 1, name: 'Bread', category: 'Carbohydrates', icon: '🍞', explanation: 'Bread is rich in starch, a complex carbohydrate used for quick energy.' },
  { id: 2, name: 'Steak', category: 'Proteins', icon: '🥩', explanation: 'Steak is muscle tissue, primarily composed of proteins for building and repair.' },
  { id: 3, name: 'Olive Oil', category: 'Lipids', icon: '🫒', explanation: 'Oils are liquid fats (lipids) used for long-term energy storage.' },
  { id: 4, name: 'DNA Helix', category: 'Nucleic Acids', icon: '🧬', explanation: 'DNA is the primary nucleic acid that carries genetic information.' },
  { id: 5, name: 'Table Sugar', category: 'Carbohydrates', icon: '🍬', explanation: 'Sucrose is a simple carbohydrate that provides immediate energy.' },
  { id: 6, name: 'Black Beans', category: 'Proteins', icon: '🫘', explanation: 'Beans are a great plant-based source of protein for cell repair.' },
  { id: 7, name: 'Butter', category: 'Lipids', icon: '🧈', explanation: 'Butter is a solid fat (lipid) used by the body for energy and insulation.' },
  { id: 8, name: 'RNA Strand', category: 'Nucleic Acids', icon: '🧪', explanation: 'RNA is a nucleic acid involved in protein synthesis and gene regulation.' },
  { id: 9, name: 'Pasta', category: 'Carbohydrates', icon: '🍝', explanation: 'Pasta contains complex carbohydrates that break down into glucose for energy.' },
  { id: 10, name: 'Eggs', category: 'Proteins', icon: '🥚', explanation: 'Eggs contain high-quality protein with all essential amino acids.' },
  { id: 11, name: 'Avocado', category: 'Lipids', icon: '🥑', explanation: 'Avocados are rich in healthy monounsaturated fats (lipids).' },
  { id: 12, name: 'ATP', category: 'Nucleic Acids', icon: '⚡', explanation: 'ATP is a nucleotide (the building block of nucleic acids) that carries energy in cells.' },
  { id: 13, name: 'Honey', category: 'Carbohydrates', icon: '🍯', explanation: 'Honey is mostly fructose and glucose, providing rapid energy.' },
  { id: 14, name: 'Chicken Breast', category: 'Proteins', icon: '🍗', explanation: 'Chicken is a lean source of protein essential for muscle growth.' },
  { id: 15, name: 'Walnuts', category: 'Lipids', icon: '🫘', explanation: 'Walnuts contain omega-3 fatty acids, which are essential lipids.' },
  { id: 16, name: 'mRNA Vaccine', category: 'Nucleic Acids', icon: '💉', explanation: 'mRNA is a nucleic acid that instructs cells to produce specific proteins.' },
  { id: 17, name: 'Potato', category: 'Carbohydrates', icon: '🥔', explanation: 'Potatoes are high in starch, a complex carbohydrate.' },
  { id: 18, name: 'Tofu', category: 'Proteins', icon: '🧊', explanation: 'Tofu is a soy-based protein used for tissue repair.' },
  { id: 19, name: 'Cheese', category: 'Lipids', icon: '🧀', explanation: 'Cheese contains significant amounts of saturated fats (lipids).' },
  { id: 20, name: 'Gene Sequence', category: 'Nucleic Acids', icon: '💻', explanation: 'Genes are segments of DNA, the master nucleic acid.' },
];

// --- Components ---

const GridOverlay = () => (
  <div className="fixed inset-0 pointer-events-none z-0 grid-overlay opacity-50" />
);

const DataStreamBackground = () => (
  <div className="fixed inset-0 pointer-events-none z-0 data-stream opacity-20" />
);

const DecorativeHUD = () => (
  <div className="fixed inset-0 pointer-events-none z-50 overflow-hidden">
    {/* Top Left Circular HUD */}
    <div className="absolute -top-10 -left-10 w-40 h-40 opacity-20">
      <div className="hud-ring w-full h-full" />
      <div className="hud-ring w-3/4 h-3/4 m-[12.5%]" />
      <div className="hud-ring-inner w-full h-full" style={{ animationDuration: '10s' }} />
    </div>
    {/* Bottom Right Circular HUD */}
    <div className="absolute -bottom-10 -right-10 w-60 h-60 opacity-20">
      <div className="hud-ring w-full h-full" />
      <div className="hud-ring w-5/6 h-5/6 m-[8.33%]" />
      <div className="hud-ring-inner w-full h-full" style={{ animationDuration: '15s', animationDirection: 'reverse' }} />
    </div>
    {/* Side Labels */}
    <div className="absolute left-4 top-1/2 -translate-y-1/2 flex flex-col gap-20 opacity-40">
      <div className="vertical-text font-mono text-[10px] tracking-[0.5em] text-[#003366] font-bold">
        <span className="tech-label mb-2">SYS_ID</span>
        NAV_SYSTEM_v4.0
      </div>
      <div className="vertical-text font-mono text-[10px] tracking-[0.5em] text-[#003366] font-bold">
        <span className="tech-label mb-2">LINK</span>
        DATA_ESTABLISHED
      </div>
    </div>
  </div>
);

const SystemLog = () => {
  const [logs, setLogs] = useState<string[]>([]);
  const logPool = [
    "MOLECULAR_SCAN_COMPLETE",
    "ENCRYPTED_DATA_RECEIVED",
    "SYSTEM_CORE_OPTIMIZED",
    "NEW_ARCHIVE_MODULE_DETECTED",
    "LATENCY_STABILIZED_12ms",
    "QUANTUM_ENCRYPTION_ACTIVE",
    "NEURAL_LINK_ESTABLISHED",
    "DATABASE_SYNC_SUCCESS"
  ];

  useEffect(() => {
    const interval = setInterval(() => {
      setLogs(prev => [logPool[Math.floor(Math.random() * logPool.length)], ...prev].slice(0, 5));
    }, 3000);
    return () => clearInterval(interval);
  }, []);

  return (
    <div className="fixed bottom-6 left-6 z-50 pointer-events-none hidden lg:block">
      <div className="flex flex-col gap-1">
        <AnimatePresence mode="popLayout">
          {logs.map((log, i) => (
            <motion.div
              key={`${log}-${i}`}
              initial={{ opacity: 0, x: -20 }}
              animate={{ opacity: 1 - i * 0.2, x: 0 }}
              exit={{ opacity: 0, x: 20 }}
              className="font-mono text-[8px] text-[#0047ab]/60 flex items-center gap-2"
            >
              <span className="w-1 h-1 bg-[#0047ab] rounded-full animate-pulse" />
              {`> ${log}`}
            </motion.div>
          ))}
        </AnimatePresence>
      </div>
    </div>
  );
};

const ParticleBackground = ({ mousePos }: { mousePos: { x: number, y: number } }) => {
  return (
    <div className="fixed inset-0 pointer-events-none z-0 overflow-hidden hexagon-bg">
      {/* DNA Helix Decorative Elements */}
      <div className="absolute top-20 -left-20 opacity-10 animate-float">
        <Dna size={300} className="text-[#0047ab] rotate-45" />
      </div>
      <div className="absolute bottom-20 -right-20 opacity-10 animate-float" style={{ animationDelay: '2s' }}>
        <Dna size={300} className="text-[#0047ab] -rotate-12" />
      </div>

      {/* Floating Atoms/Particles */}
      {Array.from({ length: 20 }).map((_, i) => {
        const factor = 0.02 + (i % 5) * 0.01;
        const translateX = (mousePos.x - window.innerWidth / 2) * factor;
        const translateY = (mousePos.y - window.innerHeight / 2) * factor;
        
        return (
          <motion.div
            key={`particle-${i}`}
            animate={{ x: translateX, y: translateY }}
            transition={{ type: 'spring', stiffness: 30, damping: 15 }}
            className="absolute w-1 h-1 bg-[#0047ab] rounded-full opacity-30"
            style={{
              left: `${(i * 7) % 100}%`,
              top: `${(i * 13) % 100}%`,
            }}
          />
        );
      })}
    </div>
  );
};

const FloatingData = () => {
  const [data, setData] = useState<string[]>([]);

  useEffect(() => {
    const interval = setInterval(() => {
      const newData = Array.from({ length: 5 }).map(() => 
        `COORD_${Math.floor(Math.random() * 999)}: ${Math.random().toFixed(4)}`
      );
      setData(newData);
    }, 2000);
    return () => clearInterval(interval);
  }, []);

  return (
    <div className="fixed inset-0 pointer-events-none z-0 overflow-hidden opacity-20">
      {data.map((text, i) => (
        <motion.div
          key={i}
          initial={{ x: Math.random() * 100 + '%', y: Math.random() * 100 + '%' }}
          animate={{ 
            y: [null, '-=100'],
            opacity: [0, 1, 1, 0]
          }}
          transition={{ duration: 10 + Math.random() * 10, repeat: Infinity, ease: "linear" }}
          className="absolute text-[8px] font-mono text-[#0ea5e9] font-bold whitespace-nowrap"
        >
          {text}
        </motion.div>
      ))}
    </div>
  );
};

const IntroScreen = ({ onStart }: { onStart: () => void }) => {
  const [loading, setLoading] = useState(0);
  const [mousePos, setMousePos] = useState({ x: 0, y: 0 });

  useEffect(() => {
    const handleMouseMove = (e: MouseEvent) => {
      setMousePos({ x: e.clientX, y: e.clientY });
    };
    window.addEventListener('mousemove', handleMouseMove);
    return () => window.removeEventListener('mousemove', handleMouseMove);
  }, []);

  useEffect(() => {
    const interval = setInterval(() => {
      setLoading(prev => {
        if (prev >= 100) {
          clearInterval(interval);
          return 100;
        }
        return prev + 1;
      });
    }, 30);
    return () => clearInterval(interval);
  }, []);

  return (
    <motion.div 
      initial={{ opacity: 1 }}
      exit={{ opacity: 0, y: -100 }}
      transition={{ duration: 0.8, ease: "easeInOut" }}
      className="fixed inset-0 z-50 flex flex-col items-center justify-center bg-slate-950 overflow-hidden"
    >
      <GridOverlay />
      <DataStreamBackground />
      <FloatingData />
      <ParticleBackground mousePos={mousePos} />
      
      {/* Rotating HUD Rings */}
      <div className="absolute inset-0 pointer-events-none overflow-hidden flex items-center justify-center opacity-20">
        <motion.div 
          animate={{ rotate: 360 }}
          transition={{ duration: 20, repeat: Infinity, ease: "linear" }}
          className="w-[800px] h-[800px] border-2 border-dashed border-cyan-500/30 rounded-full"
        />
        <motion.div 
          animate={{ rotate: -360 }}
          transition={{ duration: 30, repeat: Infinity, ease: "linear" }}
          className="absolute w-[600px] h-[600px] border border-cyan-500/20 rounded-full flex items-center justify-center"
        >
          <div className="w-full h-[1px] bg-cyan-500/20" />
          <div className="absolute w-[1px] h-full bg-cyan-500/20" />
        </motion.div>
      </div>

      <div className="absolute inset-0 opacity-30">
        <div className="absolute top-0 left-0 w-full h-full bg-[radial-gradient(circle_at_center,_var(--tw-gradient-stops))] from-cyan-500/20 via-transparent to-transparent" />
      </div>

      {/* Decorative HUD Corners for Intro */}
      <div className="absolute inset-10 pointer-events-none border-2 border-cyan-500/10">
        <div className="hud-corner-tl !w-16 !h-16 !border-cyan-500" />
        <div className="hud-corner-tr !w-16 !h-16 !border-cyan-500" />
        <div className="hud-corner-bl !w-16 !h-16 !border-cyan-500" />
        <div className="hud-corner-br !w-16 !h-16 !border-cyan-500" />
      </div>
      
      <motion.div 
        initial={{ scale: 0.9, opacity: 0 }}
        animate={{ scale: 1, opacity: 1 }}
        transition={{ duration: 1 }}
        className="relative z-10 flex flex-col items-center p-12 bg-slate-900/40 backdrop-blur-xl border border-cyan-500/30 shadow-[0_0_30px_rgba(6,182,212,0.1)]"
      >
        <div className="w-64 h-64 mb-8 relative" style={{ perspective: 1000 }}>
          {/* Reticle / Targeting System */}
          <motion.div 
            animate={{ rotate: 360 }}
            transition={{ duration: 10, repeat: Infinity, ease: "linear" }}
            className="absolute -inset-8 border border-cyan-500/40 rounded-full border-dashed"
          />
          <motion.div 
            animate={{ rotate: -360 }}
            transition={{ duration: 15, repeat: Infinity, ease: "linear" }}
            className="absolute -inset-4 border-2 border-cyan-500/30 rounded-full border-t-transparent border-b-transparent"
          />
          <div className="absolute -inset-2 border border-cyan-500/20 rounded-full" />
          
          <motion.div 
            animate={{ 
              rotateY: [0, 15, -15, 0],
              rotateX: [0, 10, -10, 0],
              y: [0, -15, 0]
            }}
            transition={{ 
              duration: 6, 
              repeat: Infinity, 
              ease: "easeInOut" 
            }}
            style={{ transformStyle: 'preserve-3d' }}
            className="absolute inset-0 flex items-center justify-center"
          >
            <img 
              src="https://i.postimg.cc/d1yTD3tx/Logo-removebg-preview.png" 
              alt="ChemQuest Logo" 
              className="w-full h-full drop-shadow-[0_0_30px_rgba(34,211,238,0.8)]"
              referrerPolicy="no-referrer"
            />
          </motion.div>

          {/* Scanning Bar over Logo */}
          <motion.div 
            animate={{ top: ["0%", "100%"] }}
            transition={{ duration: 2, repeat: Infinity, ease: "easeInOut" }}
            className="absolute left-0 w-full h-[1px] bg-cyan-400/70 z-10 shadow-[0_0_15px_rgba(34,211,238,1)]"
          />
        </div>

        <h1 
          className="text-7xl font-mono font-black tracking-tighter text-white mb-2 drop-shadow-[0_0_20px_#0ea5e9] glitch-text"
          data-text="CHEMQUEST"
        >
          CHEMQUEST
        </h1>
        <div className="flex items-center gap-4 mb-12">
          <span className="tech-label bg-cyan-500 text-slate-950">STATUS: INITIALIZING</span>
          <p className="text-cyan-400 font-mono text-sm tracking-widest uppercase font-bold">
            {loading}%
          </p>
        </div>

        <div className="w-80 h-4 bg-slate-800/50 border border-cyan-500/30 mb-12 overflow-hidden p-0.5">
          <motion.div 
            className="h-full bg-cyan-500 shadow-[0_0_10px_#0ea5e9]"
            initial={{ width: 0 }}
            animate={{ width: `${loading}%` }}
          />
        </div>

        <div className="h-12 overflow-hidden mb-12">
          <motion.div
            animate={{ y: loading < 100 ? [0, -20, -40, -60, -80, -100] : -100 }}
            transition={{ duration: 5, repeat: loading < 100 ? Infinity : 0 }}
            className="text-[10px] font-mono text-cyan-400 uppercase text-center space-y-1 font-bold"
          >
            <p>{">"} INITIALIZING...</p>
            <p>{">"} LOADING...</p>
            <p>{">"} ORGANIZING_DATA.....</p>
            <p>{">"} PREPARING...</p>
            <p>{">"} ALMOST_READY...</p>
            <p>{">"} SYSTEM_READY_FOR_DEPLOYMENT</p>
          </motion.div>
        </div>

        {loading === 100 && (
          <motion.button
            initial={{ opacity: 0, scale: 0.8 }}
            animate={{ opacity: 1, scale: 1 }}
            whileHover={{ scale: 1.05, boxShadow: "0 0 20px rgba(34,211,238,0.4)" }}
            whileTap={{ scale: 0.95 }}
            onClick={onStart}
            className="relative px-12 py-4 bg-transparent border-2 border-cyan-500 text-cyan-400 font-mono font-black text-xl uppercase tracking-widest hover:bg-cyan-500/10 transition-all shadow-[0_0_15px_rgba(34,211,238,0.2)]"
          >
            ACCESS_SYSTEM
          </motion.button>
        )}
        
        <div className="absolute -bottom-4 -right-4">
          <span className="tech-label !bg-cyan-500 !text-slate-950">v4.0.2_STABLE</span>
        </div>
      </motion.div>

      {/* Scanning Line for Intro */}
      <motion.div 
        animate={{ top: ["0%", "100%"] }}
        transition={{ duration: 3, repeat: Infinity, ease: "linear" }}
        className="absolute left-0 w-full h-[2px] bg-cyan-400/40 z-50 pointer-events-none shadow-[0_0_20px_rgba(34,211,238,0.6)]"
      >
        <div className="absolute right-4 -top-4 text-[8px] font-mono text-cyan-400 font-bold">
          SCANNING_CORE... {loading}%
        </div>
      </motion.div>

      <div className="absolute bottom-8 left-8 text-cyan-500/50 font-mono text-[10px] font-bold">
        VER 3.19.2026 // CORE_OS_READY
      </div>
      <div className="absolute top-8 right-8 text-cyan-500/50 font-mono text-[10px] font-bold text-right">
        SECTOR_7G // ENCRYPTED_LINK
      </div>
    </motion.div>
  );
};

const Navbar = ({ activePage, setActivePage, isHidden }: { activePage: Page, setActivePage: (p: Page) => void, isHidden?: boolean }) => {
  const [isOpen, setIsOpen] = useState(false);

  const navItems: { id: Page, label: string, icon: any }[] = [
    { id: 'home', label: 'HOME', icon: Home },
    { id: 'comics', label: 'COMICS', icon: BookOpen },
    { id: 'fun-facts', label: 'FUN FACTS', icon: Zap },
    { id: 'game', label: 'GAME QUEST', icon: Gamepad2 },
    { id: 'about', label: 'INFO', icon: Info },
  ];

  return (
    <nav className={`fixed top-0 left-0 w-full z-40 px-6 py-4 transition-all duration-500 ${isHidden ? '-translate-y-full opacity-0 pointer-events-none' : 'translate-y-0 opacity-100 pointer-events-auto'}`}>
      <div className="max-w-7xl mx-auto flex items-center justify-between retro-panel hologram-panel rounded-none px-6 py-3 border-[#0047ab]/50">
        <div className="flex items-center gap-3 cursor-pointer group" onClick={() => setActivePage('home')}>
          <motion.div 
            whileHover={{ rotateY: 20, rotateX: -20, scale: 1.15 }}
            style={{ perspective: 1000, transformStyle: 'preserve-3d' }}
            className="w-14 h-14 flex items-center justify-center"
          >
            <img 
              src="https://i.postimg.cc/d1yTD3tx/Logo-removebg-preview.png" 
              alt="Logo" 
              className="w-full h-full drop-shadow-[0_0_10px_rgba(14,165,233,0.4)]"
              referrerPolicy="no-referrer"
            />
          </motion.div>
          <span className="text-2xl font-mono font-black tracking-tighter text-white drop-shadow-[0_0_10px_#0ea5e9]">CHEMQUEST</span>
        </div>

        {/* Desktop Nav */}
        <div className="hidden md:flex items-center gap-4">
          {navItems.map(item => (
            <button
              key={item.id}
              onClick={() => setActivePage(item.id)}
              className={`flex items-center gap-2 font-mono font-bold text-xs uppercase tracking-widest transition-all px-4 py-2 border-2 ${
                activePage === item.id 
                  ? 'bg-cyan-600 text-white border-cyan-400 shadow-[0_0_15px_rgba(6,182,212,0.5)]' 
                  : 'text-cyan-400 border-transparent hover:border-cyan-600 hover:bg-cyan-600/10'
              }`}
            >
              <item.icon size={14} />
              {item.label}
            </button>
          ))}
        </div>

        {/* Mobile Menu Toggle */}
        <button className="md:hidden text-cyan-400 p-2 border-2 border-cyan-400" onClick={() => setIsOpen(!isOpen)}>
          {isOpen ? <X /> : <Menu />}
        </button>
      </div>

      {/* Mobile Nav */}
      <AnimatePresence>
        {isOpen && (
          <motion.div
            initial={{ opacity: 0, y: -20 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -20 }}
            className="md:hidden absolute top-24 left-6 right-6 retro-panel p-6 flex flex-col gap-4"
          >
            {navItems.map(item => (
              <button
                key={item.id}
                onClick={() => {
                  setActivePage(item.id);
                  setIsOpen(false);
                }}
                className={`flex items-center gap-4 p-4 border-2 transition-all ${
                  activePage === item.id ? 'bg-cyan-600 text-white border-cyan-600' : 'text-cyan-400 border-transparent hover:border-cyan-600'
                }`}
              >
                <item.icon size={20} />
                <span className="font-mono font-bold uppercase">{item.label}</span>
              </button>
            ))}
          </motion.div>
        )}
      </AnimatePresence>
    </nav>
  );
};

const MagneticButton = ({ children, onClick, className = "" }: { children: React.ReactNode, onClick?: () => void, className?: string }) => {
  const ref = useRef<HTMLButtonElement>(null);
  const [position, setPosition] = useState({ x: 0, y: 0 });

  const handleMouseMove = (e: React.MouseEvent) => {
    if (!ref.current) return;
    const { clientX, clientY } = e;
    const { left, top, width, height } = ref.current.getBoundingClientRect();
    const x = clientX - (left + width / 2);
    const y = clientY - (top + height / 2);
    setPosition({ x: x * 0.3, y: y * 0.3 });
  };

  const handleMouseLeave = () => {
    setPosition({ x: 0, y: 0 });
  };

  return (
    <motion.button
      ref={ref}
      onMouseMove={handleMouseMove}
      onMouseLeave={handleMouseLeave}
      onClick={onClick}
      animate={{ x: position.x, y: position.y }}
      transition={{ type: "spring", stiffness: 150, damping: 15, mass: 0.1 }}
      className={`relative ${className}`}
    >
      {children}
    </motion.button>
  );
};

const HomePage = ({ onExplore, setActivePage }: { onExplore: () => void, setActivePage: (p: Page) => void }) => {
  return (
    <motion.div 
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      exit={{ opacity: 0 }}
      className="min-h-screen pt-32 pb-20 px-6 max-w-7xl mx-auto relative z-10"
    >
      <div className="grid grid-cols-1 md:grid-cols-4 grid-rows-auto md:grid-rows-4 gap-6 h-auto md:h-[80vh]">
        {/* Main Hero Block */}
        <div className="md:col-span-2 md:row-span-3 bento-item group relative overflow-hidden">
          <div className="scan-line-vertical" />
          <div className="hud-corner-tl" />
          <div className="hud-corner-tr" />
          
          <div className="relative z-10">
            <motion.div
              initial={{ x: -20, opacity: 0 }}
              animate={{ x: 0, opacity: 1 }}
              className="inline-flex items-center gap-2 px-3 py-1 bg-[#0ea5e9] text-white text-[10px] font-bold uppercase tracking-widest mb-6"
            >
              <span className="animate-pulse">●</span> SYSTEM_READY
            </motion.div>
            
            <motion.div
              initial={{ y: -20, opacity: 0 }}
              animate={{ y: 0, opacity: 1 }}
              className="mb-6"
              style={{ perspective: 1000 }}
            >
              <motion.div
                animate={{ 
                  rotateY: [0, 10, -10, 0],
                  y: [0, -5, 0]
                }}
                transition={{ 
                  duration: 4, 
                  repeat: Infinity, 
                  ease: "easeInOut" 
                }}
                style={{ transformStyle: 'preserve-3d' }}
              >
                <img 
                  src="https://i.postimg.cc/d1yTD3tx/Logo-removebg-preview.png" 
                  alt="ChemQuest Logo" 
                  className="w-24 h-24 drop-shadow-[0_0_15px_rgba(14,165,233,0.4)]"
                  referrerPolicy="no-referrer"
                />
              </motion.div>
            </motion.div>
            
            <h2 
              className="text-6xl md:text-8xl font-mono font-black text-white mb-4 leading-none tracking-tighter uppercase glitch-text"
              data-text="CHEMQUEST"
            >
              CHEMQUEST
            </h2>

            <MagneticButton 
              onClick={onExplore}
              className="group relative w-fit px-10 py-4 bg-cyan-600 text-white font-mono font-bold cyber-button flex items-center gap-3 transition-all hover:neon-glow-cyan"
            >
              <Monitor size={18} />
              INITIALIZE_ARCHIVE
              <ChevronRight className="group-hover:translate-x-1 transition-transform" />
            </MagneticButton>
          </div>
        </div>

        {/* Quick Access: Database */}
        <div 
          onClick={() => setActivePage('fun-facts')}
          className="md:col-span-1 md:row-span-2 bento-item cursor-pointer group hover:border-[#0ea5e9] transition-colors"
        >
          <div className="flex justify-between items-start">
            <Zap className="text-[#0ea5e9] group-hover:animate-pulse" size={32} />
            <span className="tech-label">DB_01</span>
          </div>
          <div className="mt-auto">
            <h3 className="text-xl font-mono font-black mb-2">DATABASE</h3>
            <p className="text-[10px] text-slate-500 font-mono uppercase">30+ Scientific Data Points</p>
          </div>
        </div>

        {/* Quick Access: Lab Game */}
        <div 
          onClick={() => setActivePage('game')}
          className="md:col-span-1 md:row-span-2 bento-item cursor-pointer group hover:border-[#a855f7] transition-colors"
        >
          <div className="flex justify-between items-start">
            <Gamepad2 className="text-[#a855f7] group-hover:rotate-12 transition-transform" size={32} />
            <span className="tech-label bg-[#a855f7]">SIM_04</span>
          </div>
          <div className="mt-auto">
            <h3 className="text-xl font-mono font-black mb-2">GAME QUEST</h3>
            <p className="text-[10px] text-slate-500 font-mono uppercase">Interactive Molecular Synthesis</p>
          </div>
        </div>

        {/* System Stats Block */}
        <div className="md:col-span-2 md:row-span-1 bento-item flex-row items-center gap-8">
          <div className="flex-grow grid grid-cols-2 md:grid-cols-4 gap-4">
            {[
              { label: 'CPU', val: '42%' },
              { label: 'MEM', val: '88%' },
              { label: 'NET', val: '99%' },
              { label: 'TMP', val: '34°C' }
            ].map((stat, i) => (
              <div key={i}>
                <div className="text-[8px] font-mono text-[#0047ab] font-bold mb-1">{stat.label}</div>
                <div className="data-bar-bg h-2">
                  <motion.div 
                    initial={{ width: 0 }}
                    animate={{ width: stat.val }}
                    className="data-bar-fill h-full"
                  />
                </div>
              </div>
            ))}
          </div>
          <div className="hidden md:block">
            <Cpu className="text-[#0047ab]/40" size={24} />
          </div>
        </div>

        {/* Info Block */}
        <div 
          onClick={() => setActivePage('about')}
          className="md:col-span-2 md:row-span-1 bento-item flex-row items-center justify-between cursor-pointer group hover:bg-[#0047ab]/5"
        >
          <div className="flex items-center gap-4">
            <div className="w-12 h-12 border border-[#0047ab]/20 flex items-center justify-center">
              <Info className="text-[#0047ab]" size={20} />
            </div>
            <div>
              <h4 className="font-mono font-black text-sm">CHEMQUEST INFORMATION</h4>
      
            </div>
          </div>
          <ChevronRight size={20} className="text-[#0047ab] group-hover:translate-x-1 transition-transform" />
        </div>
      </div>
    </motion.div>
  );
};

const ComicReaderParticles = () => {
  const canvasRef = useRef<HTMLCanvasElement>(null);

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    let animationFrameId: number;
    
    const resize = () => {
      canvas.width = canvas.offsetWidth;
      canvas.height = canvas.offsetHeight;
    };

    window.addEventListener('resize', resize);
    resize();

    const particles: any[] = [];
    const symbols = ['H', 'He', 'Li', 'Be', 'B', 'C', 'N', 'O', 'F', 'Ne', 'Au', 'Ag'];

    for (let i = 0; i < 40; i++) {
      particles.push({
        x: Math.random() * canvas.width,
        y: Math.random() * canvas.height,
        size: Math.random() * 12 + 8,
        speed: Math.random() * 0.4 + 0.1,
        symbol: symbols[Math.floor(Math.random() * symbols.length)],
        opacity: Math.random() * 0.4 + 0.1
      });
    }

    const draw = () => {
      ctx.clearRect(0, 0, canvas.width, canvas.height);
      
      particles.forEach(p => {
        ctx.font = `bold ${p.size}px JetBrains Mono`;
        ctx.fillStyle = `rgba(0, 71, 171, ${p.opacity})`;
        ctx.fillText(p.symbol, p.x, p.y);
        
        p.y -= p.speed;
        if (p.y < -20) p.y = canvas.height + 20;
      });

      animationFrameId = requestAnimationFrame(draw);
    };

    draw();

    return () => {
      window.removeEventListener('resize', resize);
      cancelAnimationFrame(animationFrameId);
    };
  }, []);

  return (
    <canvas 
      ref={canvasRef} 
      className="absolute inset-0 w-full h-full pointer-events-none z-0 opacity-40"
    />
  );
};

const CatModel = () => {
  const meshRef = useRef<THREE.Group>(null);

  useFrame((state) => {
    if (meshRef.current) {
      meshRef.current.rotation.y = Math.sin(state.clock.elapsedTime) * 0.2;
      meshRef.current.position.y = Math.sin(state.clock.elapsedTime * 2) * 0.1;
    }
  });

  return (
    <group ref={meshRef}>
      {/* Body */}
      <mesh position={[0, 0, 0]}>
        <boxGeometry args={[0.6, 0.4, 0.8]} />
        <meshStandardMaterial color="#0047ab" metalness={0.8} roughness={0.2} />
      </mesh>
      
      {/* Head */}
      <mesh position={[0, 0.3, 0.4]}>
        <boxGeometry args={[0.4, 0.4, 0.4]} />
        <meshStandardMaterial color="#0047ab" metalness={0.8} roughness={0.2} />
      </mesh>

      {/* Ears */}
      <mesh position={[-0.15, 0.55, 0.4]}>
        <coneGeometry args={[0.1, 0.2, 4]} />
        <meshStandardMaterial color="#0ea5e9" />
      </mesh>
      <mesh position={[0.15, 0.55, 0.4]}>
        <coneGeometry args={[0.1, 0.2, 4]} />
        <meshStandardMaterial color="#0ea5e9" />
      </mesh>

      {/* Eyes */}
      <mesh position={[-0.1, 0.35, 0.6]}>
        <sphereGeometry args={[0.05, 16, 16]} />
        <meshStandardMaterial color="#0ea5e9" emissive="#0ea5e9" emissiveIntensity={2} />
      </mesh>
      <mesh position={[0.1, 0.35, 0.6]}>
        <sphereGeometry args={[0.05, 16, 16]} />
        <meshStandardMaterial color="#0ea5e9" emissive="#0ea5e9" emissiveIntensity={2} />
      </mesh>

      {/* Tail */}
      <mesh position={[0, 0.1, -0.5]} rotation={[Math.PI / 4, 0, 0]}>
        <cylinderGeometry args={[0.03, 0.03, 0.4]} />
        <meshStandardMaterial color="#0047ab" />
      </mesh>

      {/* Hover Light */}
      <pointLight position={[0, -0.5, 0]} color="#0ea5e9" intensity={2} />
    </group>
  );
};

const RobotCat = ({ containerRef }: { containerRef: React.RefObject<HTMLDivElement> }) => {
  const { scrollYProgress } = useScroll({
    container: containerRef
  });

  const y = useTransform(scrollYProgress, [0, 1], [100, 500]);
  const x = useTransform(scrollYProgress, (v: number) => 20 + Math.sin(v * 30) * 20);
  const rotate = useTransform(scrollYProgress, (v: number) => Math.sin(v * 15) * 10);

  return (
    <motion.div
      style={{ y, right: x, rotate }}
      className="absolute z-[60] pointer-events-none w-32 h-32 md:w-48 md:h-48"
    >
      <div className="w-full h-full relative">
        <div className="absolute -inset-4 bg-[#0047ab]/10 blur-xl rounded-full animate-pulse" />
        <Canvas>
          <PerspectiveCamera makeDefault position={[0, 0, 3]} />
          <ambientLight intensity={0.5} />
          <pointLight position={[10, 10, 10]} />
          <Float speed={2} rotationIntensity={1} floatIntensity={1}>
            <CatModel />
          </Float>
        </Canvas>
        <div className="absolute -bottom-4 left-1/2 -translate-x-1/2 whitespace-nowrap font-mono text-[8px] md:text-[9px] uppercase tracking-[0.2em] bg-slate-900/80 backdrop-blur-sm px-2 py-1 md:px-3 md:py-1.5 rounded-none border-2 border-cyan-500 text-cyan-400 shadow-lg">
          <span className="animate-pulse mr-2 text-[#0ea5e9]">●</span>
          GROUP 1
        </div>
      </div>
    </motion.div>
  );
};

const ComicReaderScrollHandler = ({ containerRef }: { containerRef: React.RefObject<HTMLDivElement> }) => {
  const { scrollYProgress } = useScroll({ container: containerRef });
  return (
    <>
      {/* Horizontal Progress Bar at the top of the reader */}
      <motion.div 
        className="sticky top-0 left-0 right-0 h-1.5 bg-[#0ea5e9] z-[110] origin-left shadow-[0_0_10px_rgba(14,165,233,0.5)]"
        style={{ scaleX: scrollYProgress }}
      />
      
      {/* Vertical Progress Indicator on the right */}
      <div className="fixed right-4 top-1/2 -translate-y-1/2 h-48 w-1 bg-slate-200/20 z-[110] hidden md:block rounded-full overflow-hidden pointer-events-none">
        <motion.div 
          className="w-full bg-[#0ea5e9] origin-top shadow-[0_0_10px_rgba(14,165,233,0.5)]"
          style={{ height: '100%', scaleY: scrollYProgress }}
        />
      </div>
    </>
  );
};

const ComicsPage = ({ onToggleNavbar }: { onToggleNavbar?: (hide: boolean) => void }) => {
  const [comics] = useState<Comic[]>(COMICS);
  const [selectedComic, setSelectedComic] = useState<Comic | null>(null);
  const [isReading, setIsReading] = useState(false);
  const [viewMode, setViewMode] = useState<'webtoon' | 'slideshow'>('webtoon');
  const [currentPage, setCurrentPage] = useState(0);
  const readerContainerRef = useRef<HTMLDivElement>(null);
  const [containerReady, setContainerReady] = useState(false);
  const [showScrollTop, setShowScrollTop] = useState(false);

  useEffect(() => {
    if (onToggleNavbar) {
      onToggleNavbar(!!selectedComic);
    }
    return () => {
      if (onToggleNavbar) onToggleNavbar(false);
    };
  }, [selectedComic, onToggleNavbar]);

  useEffect(() => {
    if (isReading && readerContainerRef.current) {
      setContainerReady(true);
    } else {
      setContainerReady(false);
    }
  }, [isReading, readerContainerRef.current]);

  useEffect(() => {
    const container = readerContainerRef.current;
    if (!container || !isReading) return;

    const handleScroll = () => {
      setShowScrollTop(container.scrollTop > 500);
    };

    container.addEventListener('scroll', handleScroll);
    return () => container.removeEventListener('scroll', handleScroll);
  }, [isReading, containerReady]);

  useEffect(() => {
    if (selectedComic) {
      document.body.style.overflow = 'hidden';
    } else {
      document.body.style.overflow = 'unset';
    }
    return () => {
      document.body.style.overflow = 'unset';
    };
  }, [selectedComic]);

  const scrollToTop = () => {
    readerContainerRef.current?.scrollTo({ top: 0, behavior: 'smooth' });
  };

  const handleClose = () => {
    setSelectedComic(null);
    setIsReading(false);
    setCurrentPage(0);
  };

  const nextSlide = () => {
    if (selectedComic && currentPage < selectedComic.pages.length - 1) {
      setCurrentPage(prev => prev + 1);
    }
  };

  const prevSlide = () => {
    if (currentPage > 0) {
      setCurrentPage(prev => prev - 1);
    }
  };

  return (
    <motion.div 
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      exit={{ opacity: 0 }}
      className="min-h-screen pt-32 pb-20 px-6 max-w-7xl mx-auto relative z-10"
    >
      <div className="mb-12 flex flex-col md:flex-row md:items-end justify-between gap-6">
        <div>
          <div className="tech-label mb-2">COMICS</div>
          <h2 className="text-5xl font-mono font-black text-[#0ea5e9] mb-2 tracking-tighter uppercase drop-shadow-[0_0_10px_rgba(14,165,233,0.5)]">ComicS</h2>
          <p className="text-slate-600 font-mono font-bold">Select a comic and enjoy learning through fun and engaging stories.</p>
        </div>
        <div className="flex flex-col items-end gap-4">
          <div className="flex items-center gap-4 retro-panel p-4 border-[#0047ab]">
            <div className="text-right">
              <div className="text-[10px] font-mono text-[#0ea5e9] uppercase font-bold">Comics Status</div>
              <div className="text-sm font-mono font-black text-white">ONLINE</div>
            </div>
            <Monitor className="text-[#0ea5e9]" />
          </div>
        </div>
      </div>

      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-x-8 gap-y-16">
        {comics.map((comic, index) => (
          <motion.div
            key={comic.id}
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: index * 0.1 }}
            whileHover={{ y: -10 }}
            onClick={() => setSelectedComic(comic)}
            className="group cursor-pointer relative pt-8"
          >
            <div className="folder-tab">COMICS_{index + 1}</div>
            
            <div className="retro-panel hologram-panel rounded-none border-[#0047ab] group-hover:border-[#0ea5e9] transition-all aspect-[3/4] flex flex-col overflow-hidden relative">
              <div className="card-scanline" />
              
              {/* Stacked Images Effect */}
              <div className="flex-grow relative p-4 overflow-hidden">
                {/* Back layers for stack effect */}
                <div className="absolute inset-x-6 inset-y-4 translate-x-2 -translate-y-2 bg-slate-800/40 border border-cyan-500/30 z-0" />
                <div className="absolute inset-x-5 inset-y-4 translate-x-1 -translate-y-1 bg-slate-800/60 border border-cyan-500/50 z-10" />
                
                {/* Main image container */}
                <div className="absolute inset-4 bg-slate-900 z-20 overflow-hidden border border-cyan-500/30 shadow-[0_0_15px_rgba(14,165,233,0.1)]">
                  <img 
                    src={comic.image} 
                    alt={comic.title} 
                    className="w-full h-full object-cover grayscale group-hover:grayscale-0 transition-all duration-500"
                    referrerPolicy="no-referrer"
                  />
                  
                  {/* Mini previews of the 3 pages inside */}
                  <div className="absolute bottom-0 left-0 w-full h-1/4 bg-gradient-to-t from-white to-transparent flex gap-1 p-1.5 opacity-0 group-hover:opacity-100 transition-opacity duration-300">
                    {comic.pages.map((page, i) => (
                      <div key={i} className="flex-1 border border-cyan-500/20 overflow-hidden bg-slate-800/50">
                        <img src={page} className="w-full h-full object-cover" referrerPolicy="no-referrer" />
                      </div>
                    ))}
                  </div>
                </div>
              </div>

              <div className="p-4 bg-slate-900/90 border-t border-cyan-500 relative z-30">
                <div className="flex justify-between items-center mb-1">
                  <h3 className="font-mono font-black text-white text-lg tracking-tighter uppercase group-hover:text-cyan-400 transition-colors">{comic.title}</h3>
                  <div className="w-2 h-2 rounded-full bg-[#0ea5e9] animate-pulse" />
                </div>
                <div className="flex justify-between items-center">
                  <span className="text-[10px] font-mono text-slate-500 font-bold uppercase tracking-widest">{comic.author}</span>
                  <div className="flex gap-2">
                    <button 
                      onClick={(e) => {
                        e.stopPropagation();
                        setSelectedComic(comic);
                        setIsReading(true);
                      }}
                      className="px-3 py-1 bg-cyan-500 text-slate-950 text-[10px] font-black uppercase tracking-tighter hover:bg-cyan-400 transition-colors flex items-center gap-1"
                    >
                      <BookOpen size={10} />
                      READ NOW
                    </button>
                    <div className="flex gap-1 items-center">
                      <div className="w-4 h-1 bg-[#0ea5e9]" />
                      <div className="w-2 h-1 bg-[#0ea5e9]/30" />
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </motion.div>
        ))}
      </div>

      {/* Comic Detail Modal */}
      <AnimatePresence>
        {selectedComic && (
          <motion.div 
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 z-50 flex items-center justify-center p-6 bg-blue-100/40 backdrop-blur-sm"
            onClick={handleClose}
          >
            <motion.div 
              initial={{ scale: 0.9, opacity: 0, y: 20 }}
              animate={{ scale: 1, opacity: 1, y: 0 }}
              exit={{ scale: 0.9, opacity: 0, y: 20 }}
              className="retro-panel hologram-panel w-full max-w-5xl h-[90vh] rounded-none overflow-hidden flex flex-col shadow-2xl border-cyan-500/30 bg-slate-900"
              onClick={e => e.stopPropagation()}
            >
              {!isReading ? (
                <div className="flex flex-col md:flex-row h-full overflow-y-auto custom-scrollbar">
                  <div className="w-full md:w-1/2 aspect-[3/4] md:aspect-auto relative border-r border-[#0047ab]/10">
                    <img 
                      src={selectedComic.image} 
                      alt={selectedComic.title} 
                      className="w-full h-full object-cover grayscale group-hover:grayscale-0 transition-all"
                      referrerPolicy="no-referrer"
                    />
                    <div className="absolute top-6 left-6">
                      <span className="tech-label bg-red-600 shadow-[0_0_20px_rgba(220,38,38,0.4)] animate-pulse">READING</span>
                    </div>
                  </div>
                  <div className="w-full md:w-1/2 p-8 md:p-12 flex flex-col bg-slate-900/95">
                    <div className="flex justify-between items-start mb-8">
                      <div>
                        <div className="tech-label mb-2 bg-[#0ea5e9]">COMICS: {selectedComic.id.toString().slice(-3)}</div>
                        <h3 className="text-5xl font-mono font-black text-white uppercase tracking-tighter drop-shadow-[0_0_10px_rgba(14,165,233,0.2)]">{selectedComic.title}</h3>
                      </div>
                      <button 
                        onClick={handleClose}
                        className="p-2 border border-[#0ea5e9] text-[#0ea5e9] hover:bg-[#0ea5e9] hover:text-white transition-colors"
                      >
                        <X size={24} />
                      </button>
                    </div>
                    
                    <div className="flex items-center gap-3 mb-8">
                      <div className="w-10 h-10 border border-[#0ea5e9] flex items-center justify-center bg-[#0ea5e9]/10">
                        <Info size={20} className="text-[#0ea5e9]" />
                      </div>
                      <span className="text-sm font-mono font-bold text-[#0047ab] uppercase tracking-widest">AUTHOR: {selectedComic.author.toUpperCase()}</span>
                    </div>

                    <p className="text-slate-700 font-mono font-bold leading-relaxed mb-12 flex-grow retro-panel-inset p-6 border-[#0ea5e9]/10">
                      {selectedComic.description} This comic is fun and entertaining while helping readers understand the laws of chemistry.It invites readers to explore and view the full pages..
                    </p>

                    <div className="grid grid-cols-2 gap-6">
                      <button 
                        onClick={() => setIsReading(true)}
                        className="cyber-button py-5 flex items-center justify-center gap-3 bg-[#0047ab] text-white border-[#0ea5e9]"
                      >
                        <BookOpen size={24} />
                        READ_IT
                      </button>
                      <button className="py-5 border border-[#0047ab]/30 text-[#0047ab] font-mono font-bold hover:bg-[#0047ab]/10 transition-all uppercase tracking-widest flex items-center justify-center gap-2">
                        <Monitor size={20} />
                      </button>
                    </div>
                  </div>
                </div>
              ) : (
                <div className="flex flex-col flex-grow overflow-hidden bg-[#f0f9ff]">
                  {/* Reader Header */}
                  <div className="p-6 border-b border-cyan-500/10 flex items-center justify-between bg-slate-900/80 z-10 backdrop-blur-md">
                    <div className="flex items-center gap-6">
                      <button 
                        onClick={() => setIsReading(false)}
                        className="flex items-center gap-3 text-[#0047ab] hover:text-[#0ea5e9] transition-colors font-mono text-sm font-black uppercase tracking-widest"
                      >
                        <ArrowLeft size={20} />
                        EXIT_READER
                      </button>
                      <div className="h-8 w-[1px] bg-slate-200" />
                      <div className="flex border border-cyan-500/10 p-1 bg-slate-900/40">
                        <button 
                          onClick={() => setViewMode('webtoon')}
                          className={`px-4 py-1 font-mono text-xs font-bold uppercase transition-all ${viewMode === 'webtoon' ? 'bg-cyan-600 text-white shadow-[0_0_10px_rgba(6,182,212,0.3)]' : 'text-slate-400 hover:text-white'}`}
                        >
                          WEBTOON
                        </button>
                        <button 
                          onClick={() => setViewMode('slideshow')}
                          className={`px-4 py-1 font-mono text-xs font-bold uppercase transition-all ${viewMode === 'slideshow' ? 'bg-cyan-600 text-white shadow-[0_0_10px_rgba(6,182,212,0.3)]' : 'text-slate-400 hover:text-white'}`}
                        >
                          SLIDESHOW
                        </button>
                      </div>
                    </div>

                    <div className="text-center hidden md:block">
                      <div className="tech-label mb-1 text-[#0047ab] border-[#0047ab]/30">MODE: {viewMode.toUpperCase()}</div>
                      <div className="text-lg font-mono font-black text-white uppercase drop-shadow-[0_0_5px_rgba(14,165,233,0.2)]">{selectedComic.title}</div>
                    </div>

                    <div className="flex items-center gap-6">
                      {viewMode === 'slideshow' && (
                        <div className="font-mono text-xs font-bold text-[#0047ab]">
                          PAGE: {currentPage + 1} / {selectedComic.pages.length}
                        </div>
                      )}
                      <button 
                        onClick={handleClose}
                        className="p-2 border border-[#0047ab]/20 hover:bg-[#0047ab] hover:text-white transition-colors"
                      >
                        <X size={20} />
                      </button>
                    </div>
                  </div>

                  {/* Reader Content */}
                  <div className="flex-grow relative bg-[#f0f9ff] overflow-hidden">
                    <div 
                      ref={readerContainerRef}
                      className="absolute inset-0 overflow-y-auto overflow-x-hidden scroll-smooth custom-scrollbar touch-pan-y"
                      style={{ height: '100%', WebkitOverflowScrolling: 'touch' }}
                    >
                      {/* Fixed Robot Cat Overlay - Sticky inside scrollable container */}
                      {containerReady && viewMode === 'webtoon' && (
                        <div className="sticky top-0 left-0 right-0 h-0 z-[100] pointer-events-none">
                          <div className="absolute top-8 right-8 w-48 h-48">
                            <RobotCat containerRef={readerContainerRef} />
                          </div>
                        </div>
                      )}

                      {containerReady && (
                        <ComicReaderScrollHandler containerRef={readerContainerRef} />
                      )}

                      <div className="absolute inset-0 pointer-events-none opacity-30">
                        <GridOverlay />
                        <div className="absolute inset-0 cyber-grid-bg" />
                        <ComicReaderParticles />
                      </div>
                      
                      {viewMode === 'webtoon' ? (
                        <div className="w-full max-w-3xl mx-auto flex flex-col relative z-10 gap-0 pb-32 min-h-[101%]">
                          {/* Initial Scroll Indicator */}
                        <motion.div 
                          initial={{ opacity: 0 }}
                          animate={{ opacity: 1 }}
                          className="absolute -top-12 left-1/2 -translate-x-1/2 flex flex-col items-center gap-2 text-[#0ea5e9] opacity-40"
                        >
                          <span className="text-[10px] font-mono font-bold uppercase tracking-widest">Scroll_to_Read</span>
                          <motion.div 
                            animate={{ y: [0, 5, 0] }}
                            transition={{ duration: 2, repeat: Infinity }}
                          >
                            <ArrowLeft size={16} className="-rotate-90" />
                          </motion.div>
                        </motion.div>

                        {selectedComic.pages.map((page, idx) => (
                          <motion.div
                            key={idx}
                            initial={{ opacity: 0 }}
                            whileInView={{ opacity: 1 }}
                            viewport={{ once: true, margin: "0px" }}
                            transition={{ duration: 1, ease: "linear" }}
                            className="w-full relative m-0 p-0 leading-[0]"
                          >
                            <img 
                              src={page} 
                              alt={`Page ${idx + 1}`} 
                              className="w-full h-auto block m-0 p-0 border-x border-blue-100"
                              referrerPolicy="no-referrer"
                            />
                            {/* Seamless glow transition between images */}
                            <div className="absolute bottom-0 left-0 right-0 h-32 bg-gradient-to-t from-[#0ea5e9]/5 to-transparent pointer-events-none z-20" />
                            <div className="absolute top-0 left-0 right-0 h-32 bg-gradient-to-b from-[#0ea5e9]/5 to-transparent pointer-events-none z-20" />
                            
                            {/* Page Indicator HUD */}
                            <div className="absolute top-8 right-8 opacity-40 group-hover:opacity-100 transition-opacity">
                              <div className="flex items-center gap-2">
                                <div className="w-1 h-1 bg-[#0ea5e9] rounded-full animate-pulse" />
                                <span className="tech-label bg-transparent border border-[#0ea5e9] text-[#0ea5e9]">COMIC_PAGE_{idx + 1}</span>
                              </div>
                            </div>
                          </motion.div>
                        ))}
                        
                        {/* Next Module Link */}
                        <div className="py-20 px-10 text-center border-t border-cyan-500/10 bg-slate-900/60 backdrop-blur-sm mt-10">
                          <div className="tech-label mb-4 mx-auto w-fit text-[#0047ab] border-[#0047ab]/30">END</div>
                          <h4 className="text-3xl font-mono font-black text-white mb-8 uppercase tracking-tighter">Next Comics Available</h4>
                          <button 
                            onClick={() => {
                              const nextIdx = (comics.findIndex(c => c.id === selectedComic.id) + 1) % comics.length;
                              setSelectedComic(comics[nextIdx]);
                              setCurrentPage(0);
                              readerContainerRef.current?.scrollTo(0, 0);
                            }}
                            className="cyber-button px-10 py-4 text-lg"
                          >
                            COMICS
                          </button>
                        </div>
                      </div>
                    ) : (
                      <div className="h-full flex flex-col items-center justify-center p-8 relative z-10">
                        <AnimatePresence mode="wait">
                          <motion.div
                            key={currentPage}
                            initial={{ opacity: 0, x: 20 }}
                            animate={{ opacity: 1, x: 0 }}
                            exit={{ opacity: 0, x: -20 }}
                            className="h-full max-w-4xl w-full flex items-center justify-center"
                          >
                            <div className="relative border border-cyan-500/20 shadow-[0_0_30px_rgba(6,182,212,0.1)] bg-slate-900">
                              <img 
                                src={selectedComic.pages[currentPage]} 
                                alt={`Page ${currentPage + 1}`} 
                                className="max-h-[70vh] max-w-full object-contain"
                                referrerPolicy="no-referrer"
                              />
                              <div className="absolute top-6 right-6">
                                <span className="tech-label text-[#0047ab] border-[#0047ab]/30">PAGE_{currentPage + 1}</span>
                              </div>
                            </div>
                          </motion.div>
                        </AnimatePresence>

                        {/* Slideshow Controls */}
                        <div className="absolute bottom-12 left-0 right-0 flex justify-center gap-12">
                          <button 
                            onClick={prevSlide}
                            disabled={currentPage === 0}
                            className={`p-4 border border-cyan-500 transition-all bg-slate-900/60 ${currentPage === 0 ? 'opacity-20 cursor-not-allowed' : 'hover:bg-cyan-600 hover:text-white hover:shadow-[0_0_15px_rgba(6,182,212,0.5)]'}`}
                          >
                            <ChevronLeft size={32} />
                          </button>
                          <div className="flex items-center gap-4">
                            {selectedComic.pages.map((_, i) => (
                              <div 
                                key={i} 
                                className={`w-3 h-3 border border-[#0047ab] ${i === currentPage ? 'bg-[#0ea5e9] shadow-[0_0_10px_#0ea5e9]' : 'bg-transparent'}`}
                              />
                            ))}
                          </div>
                          <button 
                            onClick={nextSlide}
                            disabled={currentPage === selectedComic.pages.length - 1}
                            className={`p-4 border border-cyan-500 transition-all bg-slate-900/60 ${currentPage === selectedComic.pages.length - 1 ? 'opacity-20 cursor-not-allowed' : 'hover:bg-cyan-600 hover:text-white hover:shadow-[0_0_15px_rgba(6,182,212,0.5)]'}`}
                          >
                            <ChevronRight size={32} />
                          </button>
                        </div>
                      </div>
                    )}

                    {/* Scroll to Top Button */}
                    <AnimatePresence>
                      {showScrollTop && viewMode === 'webtoon' && (
                        <motion.button
                          initial={{ opacity: 0, y: 20 }}
                          animate={{ opacity: 1, y: 0 }}
                          exit={{ opacity: 0, y: 20 }}
                          onClick={scrollToTop}
                          className="fixed bottom-8 right-8 w-12 h-12 bg-[#0047ab] text-white flex items-center justify-center shadow-[0_0_20px_rgba(0,71,171,0.4)] z-[110] hover:bg-[#0ea5e9] transition-colors"
                        >
                          <ChevronRight size={24} className="-rotate-90" />
                        </motion.button>
                      )}
                    </AnimatePresence>
                  </div>
                </div>
              </div>
            )}
          </motion.div>
        </motion.div>
      )}
    </AnimatePresence>
  </motion.div>
);
};

const FunFactsPage = () => {
  const [activeCategory, setActiveCategory] = useState<'all' | 'biomolecules' | 'reactions'>('all');

  const filteredFacts = activeCategory === 'all' 
    ? FUN_FACTS 
    : FUN_FACTS.filter(f => f.category === activeCategory);

  return (
    <motion.div 
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      exit={{ opacity: 0 }}
      className="min-h-screen pt-32 pb-20 px-6 max-w-7xl mx-auto"
    >
      <div className="mb-12 text-center">
        <div className="tech-label mb-4 mx-auto w-fit">FUNFACTS</div>
        <h2 className="text-5xl font-mono font-black text-white mb-4 tracking-tighter uppercase drop-shadow-[0_0_15px_#0ea5e9]">Biomolecules And Chemical Reactions</h2>
        
        {/* Category Filter */}
        <div className="flex flex-wrap justify-center gap-4 mb-8">
          {[
            { id: 'all', label: 'ALL DATA', icon: Zap },
            { id: 'biomolecules', label: 'BIOMOLECULES', icon: Dna },
            { id: 'Chemical reactions', label: 'CHEMICAL REACTIONS', icon: FlaskConical }
          ].map((cat) => (
            <button
              key={cat.id}
              onClick={() => setActiveCategory(cat.id as any)}
              className={`flex items-center gap-2 px-6 py-2 font-mono text-xs font-bold tracking-widest transition-all border ${
                activeCategory === cat.id 
                  ? 'bg-[#0ea5e9] text-white border-[#0ea5e9] shadow-[0_0_15px_rgba(14,165,233,0.5)]' 
                  : 'bg-slate-900 text-cyan-400 border-cyan-400/30 hover:border-cyan-400 hover:bg-cyan-400/5'
              }`}
            >
              <cat.icon size={14} />
              {cat.label}
            </button>
          ))}
        </div>

        <p className="text-[#0ea5e9] font-mono font-bold uppercase tracking-widest text-xs">
          {filteredFacts.length} fascinating facts discovered from {activeCategory === 'all' ? 'group 1 members' : activeCategory} database.
        </p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        <AnimatePresence mode="popLayout">
          {filteredFacts.map((fact, index) => (
            <motion.div
              key={fact.id}
              layout
              initial={{ opacity: 0, scale: 0.9 }}
              animate={{ opacity: 1, scale: 1 }}
              exit={{ opacity: 0, scale: 0.9 }}
              transition={{ duration: 0.2 }}
              whileHover={{ scale: 1.03, boxShadow: "0 0 30px rgba(14, 165, 233, 0.3)" }}
              className="retro-panel hologram-panel p-6 rounded-none border-cyan-500/30 transition-all hover:border-cyan-400 group relative overflow-hidden h-full"
            >
              <div className="card-scanline" />
              <div className="flex items-start gap-4 relative z-10">
                <div className="w-10 h-10 bg-slate-800/40 border border-cyan-500/30 flex items-center justify-center shrink-0 group-hover:bg-cyan-500 transition-colors shadow-[0_0_10px_rgba(14,165,233,0.3)]">
                  {fact.category === 'biomolecules' ? (
                    <Dna size={20} className="text-cyan-400 group-hover:text-white transition-colors" />
                  ) : (
                    <FlaskConical size={20} className="text-cyan-400 group-hover:text-white transition-colors" />
                  )}
                </div>
                <div>
                  <div className="flex items-center gap-2 mb-1">
                    <div className="text-[10px] font-mono text-cyan-400 uppercase tracking-widest font-bold">ID: {fact.id.toString().padStart(2, '0')}</div>
                    <div className="text-[8px] font-mono bg-cyan-500/10 text-cyan-400 px-1 border border-cyan-500/20 uppercase font-bold">
                      {fact.category}
                    </div>
                  </div>
                  <p className="text-slate-300 text-sm leading-relaxed font-mono font-bold">{fact.fact}</p>
                </div>
              </div>
            </motion.div>
          ))}
        </AnimatePresence>
      </div>
    </motion.div>
  );
};

const ScrollingClock = () => {
  const [time, setTime] = useState(new Date());
  const { scrollYProgress } = useScroll();
  const rotate = useTransform(scrollYProgress, [0, 1], [0, 360]);
  const opacity = useTransform(scrollYProgress, [0, 0.05], [0, 1]);

  useEffect(() => {
    const timer = setInterval(() => setTime(new Date()), 1000);
    return () => clearInterval(timer);
  }, []);

  const formatTime = (date: Date) => {
    return date.toLocaleTimeString('en-US', { 
      hour12: false, 
      hour: '2-digit', 
      minute: '2-digit', 
      second: '2-digit' 
    });
  };

  return (
    <motion.div 
      style={{ opacity }}
      className="fixed right-8 top-1/2 -translate-y-1/2 z-50 pointer-events-none hidden xl:flex flex-col items-center gap-6"
    >
      <div className="relative w-28 h-28 flex items-center justify-center">
        {/* Rotating outer ring */}
        <motion.div 
          style={{ rotate }}
          className="absolute inset-0 border border-dashed border-cyan-500/30 rounded-full"
        />
        {/* Static inner ring */}
        <div className="absolute inset-4 border border-cyan-400/10 rounded-full" />
        {/* Pulse effect */}
        <div className="absolute inset-0 border border-cyan-500/5 rounded-full animate-ping" />
        
        {/* Time Display */}
        <div className="flex flex-col items-center">
          <div className="text-[9px] font-mono text-cyan-400/60 tracking-widest uppercase mb-1">Local_Time</div>
          <div className="text-sm font-display font-bold text-cyan-400 neon-text-cyan">
            {formatTime(time)}
          </div>
          <div className="text-[8px] font-mono text-cyan-400/40 mt-1">UTC_SYNC_OK</div>
        </div>
      </div>

      {/* Vertical Scroll Progress Bar */}
      <div className="flex flex-col items-center gap-2">
        <div className="h-32 w-[2px] bg-cyan-100/20 rounded-full overflow-hidden relative">
          <motion.div 
            style={{ height: useTransform(scrollYProgress, [0, 1], ['0%', '100%']) }}
            className="absolute top-0 left-0 w-full bg-cyan-500 shadow-[0_0_10px_rgba(34,211,238,0.8)]"
          />
        </div>
        <div className="font-mono text-[9px] text-cyan-400/40 vertical-text tracking-[0.3em] uppercase">
          Scroll_Progress
        </div>
      </div>
      
      {/* HUD Details */}
      <div className="flex flex-col gap-1 items-center">
        <div className="w-8 h-[1px] bg-cyan-500/30" />
        <div className="text-[8px] font-mono text-cyan-400/40 uppercase">Sector_07</div>
      </div>
    </motion.div>
  );
};

// --- Helpers ---
const shuffleArray = <T,>(array: T[]): T[] => {
  const newArray = [...array];
  for (let i = newArray.length - 1; i > 0; i--) {
    const j = Math.floor(Math.random() * (i + 1));
    [newArray[i], newArray[j]] = [newArray[j], newArray[i]];
  }
  return newArray;
};

// --- Constants ---
const BIOMOLECULE_CATEGORIES = [
  { name: 'Carbohydrates', desc: 'Quick energy', icon: '🍞' },
  { name: 'Proteins', desc: 'Building & repair', icon: '🥩' },
  { name: 'Lipids', desc: 'Long-term energy', icon: '🧈' },
  { name: 'Nucleic Acids', desc: 'Genetic material', icon: '🧬' },
];

const BiomoleculeGame = () => {
  const [showInstructions, setShowInstructions] = useState(true);
  const [shuffledItems, setShuffledItems] = useState(() => shuffleArray(BIOMOLECULE_ITEMS));
  const [currentIndex, setCurrentIndex] = useState(0);
  const [score, setScore] = useState(0);
  const [lives, setLives] = useState(5);
  const [timeLeft, setTimeLeft] = useState(30);
  const [feedback, setFeedback] = useState<{ isCorrect: boolean; message: string } | null>(null);
  const [gameFinished, setGameFinished] = useState(false);
  const [shuffledCategories, setShuffledCategories] = useState(() => shuffleArray(BIOMOLECULE_CATEGORIES));

  const currentItem = shuffledItems[currentIndex];

  useEffect(() => {
    let timer: NodeJS.Timeout;
    if (!showInstructions && !gameFinished && !feedback && timeLeft > 0) {
      timer = setInterval(() => {
        setTimeLeft(prev => prev - 1);
      }, 1000);
    } else if (timeLeft === 0 && !feedback && !gameFinished) {
      handleSelect('TIMEOUT');
    }
    return () => clearInterval(timer);
  }, [showInstructions, gameFinished, feedback, timeLeft]);

  const handleSelect = (category: string) => {
    if (feedback || gameFinished) return;

    const isCorrect = category === currentItem.category;
    if (isCorrect) {
      setScore(s => s + 10 + timeLeft);
    } else {
      setLives(l => l - 1);
      if (lives <= 1) {
        setGameFinished(true);
      }
    }
    
    setFeedback({
      isCorrect,
      message: category === 'TIMEOUT' ? "Time's up! You need to be faster." : currentItem.explanation
    });
  };

  const nextItem = () => {
    setFeedback(null);
    setTimeLeft(30);
    if (currentIndex < shuffledItems.length - 1 && lives > 0) {
      setCurrentIndex(c => c + 1);
    } else {
      setGameFinished(true);
    }
  };

  const restart = () => {
    setShuffledItems(shuffleArray(BIOMOLECULE_ITEMS));
    setCurrentIndex(0);
    setScore(0);
    setLives(5);
    setTimeLeft(30);
    setFeedback(null);
    setGameFinished(false);
    setShowInstructions(true);
  };

  if (showInstructions) {
    return (
      <motion.div 
        initial={{ opacity: 0, scale: 0.9 }}
        animate={{ opacity: 1, scale: 1 }}
        className="relative z-10 text-center"
      >
        <h2 className="text-3xl font-mono font-black text-white mb-6 uppercase tracking-tighter">Biomolecule Quest: Instructions</h2>
        <div className="space-y-4 text-left mb-8 font-mono font-bold text-slate-300 max-w-lg mx-auto bg-slate-900/40 p-6 border border-cyan-500/20">
          <p className="border-l-4 border-cyan-500 pl-4"><strong>HOW TO PLAY:</strong></p>
          <p className="pl-4">1. You will be given a biological item or description.</p>
          <p className="pl-4">2. Classify it into one of the 4 categories below.</p>
          <p className="pl-4">3. You have <strong>30 seconds</strong> per item.</p>
          <p className="pl-4">4. You have <strong>5 lives</strong>. Be careful!</p>
          <hr className="border-cyan-500/10 my-4" />
          <p className="border-l-4 border-cyan-500 pl-4"><strong>QUICK GUIDE:</strong></p>
          <p className="pl-4">🍞 <strong>Carbohydrates</strong>: Sugars & Starches (Energy)</p>
          <p className="pl-4">🥩 <strong>Proteins</strong>: Building blocks & Enzymes</p>
          <p className="pl-4">🧈 <strong>Lipids</strong>: Fats & Oils (Storage)</p>
          <p className="pl-4">🧬 <strong>Nucleic Acids</strong>: DNA & RNA (Genetics)</p>
        </div>
        <button onClick={() => setShowInstructions(false)} className="cyber-button px-12 py-4 text-lg">
          START_SIMULATION
        </button>
      </motion.div>
    );
  }

  if (gameFinished) {
    return (
      <motion.div 
        initial={{ opacity: 0, scale: 0.9 }}
        animate={{ opacity: 1, scale: 1 }}
        className="relative z-10 text-center"
      >
        <h2 className="text-4xl font-mono font-black text-white mb-4 uppercase tracking-tighter">
          {lives > 0 ? 'Mission Complete' : 'System Failure'}
        </h2>
        <div className="text-6xl font-mono font-black text-[#0ea5e9] mb-8 drop-shadow-[0_0_15px_#0ea5e9]">
          SCORE: {score}
        </div>
        <p className="text-slate-400 mb-12 font-mono font-bold uppercase">
          {lives > 0 
            ? 'You have successfully classified all biological data modules.' 
            : 'Too many classification errors. Simulation terminated.'}
        </p>
        <button onClick={restart} className="cyber-button px-12 py-4">
          REPLAY_GAME
        </button>
      </motion.div>
    );
  }

  return (
    <div className="relative z-10">
      <div className="flex justify-between items-center mb-8">
        <div className="flex gap-4">
          <div className="tech-label">LEVEL: {currentIndex + 1} / {shuffledItems.length}</div>
          <div className="tech-label bg-red-500">LIVES: {Array(lives).fill('❤️').join('')}</div>
        </div>
        <div className="flex flex-col items-center">
          <button 
            onClick={() => setShowInstructions(true)}
            className="text-[10px] font-mono font-bold text-cyan-400 hover:text-[#0ea5e9] uppercase border-b border-cyan-500/20 mb-1"
          >
            [ INSTRUCTIONS ]
          </button>
        </div>
        <div className="flex gap-4">
          <div className={`tech-label ${timeLeft < 5 ? 'bg-red-500 animate-pulse' : 'bg-orange-500'}`}>TIME: {timeLeft}s</div>
          <div className="tech-label bg-[#0ea5e9]">SCORE: {score}</div>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
        {/* Item to classify */}
        <div className="flex flex-col items-center">
          <AnimatePresence mode="wait">
            <motion.div
              key={currentItem.id}
              initial={{ x: 50, opacity: 0 }}
              animate={{ x: 0, opacity: 1 }}
              exit={{ x: -50, opacity: 0 }}
              className="w-64 h-64 retro-panel hologram-panel flex flex-col items-center justify-center relative group cursor-grab active:cursor-grabbing"
              drag
              dragConstraints={{ left: 0, right: 0, top: 0, bottom: 0 }}
              dragElastic={0.5}
            >
              <div className="text-8xl mb-4">{currentItem.icon}</div>
              <div className="text-2xl font-mono font-black text-white uppercase tracking-tighter text-center px-4">{currentItem.name}</div>
              <div className="card-scanline" />
            </motion.div>
          </AnimatePresence>
          <p className="mt-6 text-slate-500 font-mono text-xs uppercase font-bold animate-pulse">
            {"<"} DRAG OR TAP TO CLASSIFY {">"}
          </p>
        </div>

        {/* Categories */}
        <div className="grid grid-cols-2 gap-4">
          {shuffledCategories.map((cat) => (
            <motion.button
              key={cat.name}
              whileHover={{ scale: 1.05 }}
              whileTap={{ scale: 0.95 }}
              onClick={() => handleSelect(cat.name)}
              className={`p-6 retro-panel flex flex-col items-center justify-center text-center transition-all border-2 ${
                feedback && cat.name === currentItem.category 
                  ? 'border-green-500 bg-green-900/50' 
                  : feedback && cat.name !== currentItem.category
                  ? 'border-slate-800 opacity-50'
                  : 'border-cyan-500/20 hover:border-cyan-400'
              }`}
            >
              <div className="text-3xl mb-2">{cat.icon}</div>
              <div className="font-mono font-black text-white text-sm uppercase tracking-tighter">{cat.name}</div>
              <div className="text-[10px] font-mono text-slate-400 font-bold uppercase mt-1">{cat.desc}</div>
            </motion.button>
          ))}
        </div>
      </div>

      {/* Feedback Overlay */}
      <AnimatePresence>
        {feedback && (
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: 20 }}
            className={`mt-12 p-8 retro-panel border-2 ${feedback.isCorrect ? 'border-green-500 bg-green-50/80' : 'border-red-500 bg-red-50/80'}`}
          >
            <div className="flex flex-col md:flex-row items-start gap-6">
              <div className={`w-16 h-16 shrink-0 flex items-center justify-center border-2 ${feedback.isCorrect ? 'border-green-500 text-green-500' : 'border-red-500 text-red-500'}`}>
                {feedback.isCorrect ? <Zap size={32} /> : <X size={32} />}
              </div>
              <div>
                <h3 className={`text-2xl font-mono font-black mb-2 uppercase tracking-tighter ${feedback.isCorrect ? 'text-green-700' : 'text-red-700'}`}>
                  {feedback.isCorrect ? 'DATA_VERIFIED' : 'ERROR: MISCLASSIFIED'}
                </h3>
                <p className="font-mono font-bold text-slate-700 leading-relaxed">
                  {feedback.message}
                </p>
                <button onClick={nextItem} className="mt-6 cyber-button px-8 py-2">
                  CONTINUE_SEQUENCE
                </button>
              </div>
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
};

const GamePage = () => {
  return (
    <motion.div 
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      exit={{ opacity: 0 }}
      className="min-h-screen pt-32 pb-20 px-6 max-w-6xl mx-auto"
    >
      <div className="mb-12 flex flex-col md:flex-row items-center justify-between gap-6">
        <div className="text-center md:text-left">
          <div className="tech-label mb-2"> GAME QUEST</div>
          <h2 className="text-5xl font-mono font-black text-white mb-2 tracking-tighter uppercase drop-shadow-[0_0_15px_#0ea5e9]">Game Center</h2>
          <p className="text-[#0ea5e9] font-mono font-bold uppercase tracking-widest text-xs">Begin your game quest.</p>
        </div>
      </div>

      <div className="retro-panel hologram-panel p-8 md:p-12 rounded-none border-[#0047ab]/50 relative overflow-hidden">
        <div className="hud-corner-tl !w-12 !h-12" />
        <div className="hud-corner-tr !w-12 !h-12" />
        <div className="hud-corner-bl !w-12 !h-12" />
        <div className="hud-corner-br !w-12 !h-12" />
        
        <BiomoleculeGame />
      </div>
    </motion.div>
  );
};

const AboutPage = () => {
  return (
    <motion.div 
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      exit={{ opacity: 0 }}
      className="min-h-screen pt-32 pb-20 px-6 max-w-4xl mx-auto"
    >
      <div className="retro-panel hologram-panel p-12 rounded-none relative overflow-hidden border-[#0047ab]/50">
        <div className="hud-corner-tl !w-12 !h-12" />
        <div className="hud-corner-tr !w-12 !h-12" />
        <div className="hud-corner-bl !w-12 !h-12" />
        <div className="hud-corner-br !w-12 !h-12" />

        <div className="relative z-10">
          <div className="flex items-center justify-between mb-8">
            <div>
              <div className="text-cyan-400 font-mono text-xs uppercase tracking-[0.3em] mb-4 font-bold">Group1</div>
              <h2 className="text-5xl font-mono font-black text-white tracking-tighter uppercase drop-shadow-[0_0_15px_#0ea5e9]">CHEM QUEST INFORMATION</h2>
            </div>
            <motion.div 
              animate={{ rotateY: 360 }}
              transition={{ duration: 10, repeat: Infinity, ease: "linear" }}
              style={{ perspective: 1000, transformStyle: 'preserve-3d' }}
            >
              <img 
                src="https://i.postimg.cc/d1yTD3tx/Logo-removebg-preview.png" 
                alt="Logo" 
                className="w-32 h-32 drop-shadow-[0_0_20px_rgba(14,165,233,0.5)]"
                referrerPolicy="no-referrer"
              />
            </motion.div>
          </div>
          
          <div className="space-y-6 text-slate-300 leading-relaxed font-mono font-bold">
            <p>
              Group 1  Grade 10 | St. Pio of Tarlac Montessori School
              ChemQuest members: 
              "Renee Abalos – Comic Creator & 10 Fun Facts,"
              "Rhiana Briones – Website creator, Comic Creator & added 10 Fun Facts,"
              "Rachel Chan – Comic Creator & added 10 Fun Facts,"
              "Gian Ico – Comic Creator & added 10 Fun Facts,"
"Enzo Moyano – Comic Creator & 10 added Fun Facts,"
"Joseph Tesorero – Comic Creator & added 10 Fun Facts,"
"Janine Ticman – Comic Creator & added 10 Fun Facts."
            </p>
            <p>
               This website was created as part of a science project to organize and present all the scaffolds in science.
            </p>
          </div>

        </div>
      </div>
    </motion.div>
  );
};

const GlitchOverlay = () => {
  const [isGlitching, setIsGlitching] = useState(false);

  useEffect(() => {
    const triggerGlitch = () => {
      if (Math.random() > 0.95) {
        setIsGlitching(true);
        setTimeout(() => setIsGlitching(false), 150);
      }
    };

    const interval = setInterval(triggerGlitch, 2000);
    return () => clearInterval(interval);
  }, []);

  if (!isGlitching) return null;

  return (
    <div className="fixed inset-0 pointer-events-none z-[10000] mix-blend-overlay opacity-30">
      <div className="absolute inset-0 bg-cyan-500/20 translate-x-1" />
      <div className="absolute inset-0 bg-magenta-500/20 -translate-x-1" />
    </div>
  );
};

const CustomCursor = ({ mousePos }: { mousePos: { x: number, y: number } }) => {
  return (
    <>
      <motion.div
        animate={{ x: mousePos.x - 16, y: mousePos.y - 16 }}
        transition={{ type: "spring", stiffness: 500, damping: 28, mass: 0.5 }}
        className="fixed top-0 left-0 w-8 h-8 border border-[#0ea5e9] rounded-full pointer-events-none z-[10001] hidden md:block"
      />
      <motion.div
        animate={{ x: mousePos.x - 2, y: mousePos.y - 2 }}
        transition={{ type: "spring", stiffness: 1000, damping: 40, mass: 0.1 }}
        className="fixed top-0 left-0 w-1 h-1 bg-[#0ea5e9] rounded-full pointer-events-none z-[10001] hidden md:block"
      />
    </>
  );
};

export default function App() {
  const [page, setPage] = useState<Page>('intro');
  const [mousePos, setMousePos] = useState({ x: 0, y: 0 });
  const [hideNavbar, setHideNavbar] = useState(false);

  useEffect(() => {
    const handleMouseMove = (e: MouseEvent) => {
      setMousePos({ x: e.clientX, y: e.clientY });
    };
    window.addEventListener('mousemove', handleMouseMove);
    return () => window.removeEventListener('mousemove', handleMouseMove);
  }, []);

  // Sound effect placeholder
  const playClick = () => {
    console.log('Sound effect: Click triggered');
  };

  const handlePageChange = (newPage: Page) => {
    playClick();
    setPage(newPage);
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  return (
    <div className="font-sans antialiased cursor-none">
      <div className="scanline" />
      <GlitchOverlay />
      <CustomCursor mousePos={mousePos} />
      
      <AnimatePresence mode="wait">
        {page === 'intro' ? (
          <motion.div key="intro" initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }}>
            <IntroScreen onStart={() => handlePageChange('home')} />
          </motion.div>
        ) : (
          <motion.div 
            key="main"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            className="relative min-h-screen"
          >
            <GridOverlay />
            <DataStreamBackground />
            <DecorativeHUD />
            <SystemLog />
            <ParticleBackground mousePos={mousePos} />
            <ScrollingClock />

            <Navbar activePage={page} setActivePage={handlePageChange} isHidden={hideNavbar} />
            
            <main className="relative z-10">
              <AnimatePresence mode="wait">
                {page === 'home' && (
                  <motion.div key="home" initial={{ opacity: 0, x: 20 }} animate={{ opacity: 1, x: 0 }} exit={{ opacity: 0, x: -20 }}>
                    <HomePage onExplore={() => handlePageChange('comics')} setActivePage={handlePageChange} />
                  </motion.div>
                )}
                {page === 'comics' && (
                  <motion.div key="comics" initial={{ opacity: 0, x: 20 }} animate={{ opacity: 1, x: 0 }} exit={{ opacity: 0, x: -20 }}>
                    <ComicsPage onToggleNavbar={setHideNavbar} />
                  </motion.div>
                )}
                {page === 'fun-facts' && (
                  <motion.div key="fun-facts" initial={{ opacity: 0, x: 20 }} animate={{ opacity: 1, x: 0 }} exit={{ opacity: 0, x: -20 }}>
                    <FunFactsPage />
                  </motion.div>
                )}
                {page === 'about' && (
                  <motion.div key="about" initial={{ opacity: 0, x: 20 }} animate={{ opacity: 1, x: 0 }} exit={{ opacity: 0, x: -20 }}>
                    <AboutPage />
                  </motion.div>
                )}
                {page === 'game' && (
                  <motion.div key="game" initial={{ opacity: 0, x: 20 }} animate={{ opacity: 1, x: 0 }} exit={{ opacity: 0, x: -20 }}>
                    <GamePage />
                  </motion.div>
                )}
              </AnimatePresence>
            </main>

            <footer className="relative z-10 py-12 px-6 border-t border-cyan-500/20 mt-20 glass-panel">
              <div className="max-w-7xl mx-auto flex flex-col md:flex-row items-center justify-between gap-6">
                <div className="flex items-center gap-3">
                  <motion.div
                    animate={{ rotateY: [0, 360] }}
                    transition={{ duration: 8, repeat: Infinity, ease: "linear" }}
                    style={{ perspective: 1000, transformStyle: 'preserve-3d' }}
                  >
                    <img 
                      src="https://i.postimg.cc/d1yTD3tx/Logo-removebg-preview.png" 
                      alt="ChemQuest Logo" 
                      className="w-12 h-12"
                      referrerPolicy="no-referrer"
                    />
                  </motion.div>
                  <span className="text-lg font-display font-bold text-white neon-text-cyan">ChemQuest</span>
                </div>
                <div className="text-cyan-400/60 text-[10px] font-mono uppercase tracking-widest">
                  © 2026 CHEMQUEST // 
                </div>
                <div className="flex gap-6">
                  <button className="text-cyan-400/60 hover:text-cyan-400 transition-colors"><Monitor size={20} /></button>
                  <button className="text-cyan-400/60 hover:text-cyan-400 transition-colors"><Cpu size={20} /></button>
                  <button className="text-cyan-400/60 hover:text-cyan-400 transition-colors"><Dna size={20} /></button>
                </div>
              </div>
            </footer>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}
